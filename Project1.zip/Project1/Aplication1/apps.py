from django.apps import AppConfig


class Aplication1Config(AppConfig):
    name = 'Aplication1'
